import csv, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from sna.core import create_split,get_splits,build_prompts,audit,json_write,parse_profile

def test_no_holdout_in_prompts(tmp_path):
    (tmp_path/'data/raw').mkdir(parents=True)
    (tmp_path/'outputs').mkdir()
    with (tmp_path/'data/raw/items.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['item_id','name','city','categories']);w.writerow(['x','X','C','Food']);w.writerow(['y','Y','C','Other'])
    with (tmp_path/'data/raw/interactions.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['user_id','item_id','review_id','review_text','timestamp'])
        for i in range(10):w.writerow(['u','x' if i%2==0 else 'y',str(i),'review '+str(i),f'2026-01-{i+1:02d}'])
    cfg={'data':{'interactions':'data/raw/interactions.csv','items':'data/raw/items.csv','timestamp_column':'timestamp','review_column':'review_text'},'paths':{'output':'outputs'},'split':{'policy':'user_temporal_if_available','seed':42,'valid_ratio':0.1,'test_ratio':0.1},'llm':{'max_input_reviews_per_item':None}}
    manifest=create_split(cfg,tmp_path)
    assert manifest['counts']=={'train':8,'valid':1,'test':1}
    rows,_=get_splits(cfg,tmp_path)
    validtest={r['review_id'] for s in ('valid','test') for r in rows[s]}
    item_prompts=build_prompts(cfg,tmp_path,'item')
    assert all(not (set(p['source_review_ids']) & validtest) for p in item_prompts)
    assert all('review 8' not in p['prompt'] and 'review 9' not in p['prompt'] for p in item_prompts)
    assert audit(cfg,tmp_path)['train_only_source_check']=='PASS'

def test_parse_json_codefence():
    x=parse_profile('```json\n{"summarization":"ok","reasoning":"because"}\n```')
    assert x['summarization']=='ok'
