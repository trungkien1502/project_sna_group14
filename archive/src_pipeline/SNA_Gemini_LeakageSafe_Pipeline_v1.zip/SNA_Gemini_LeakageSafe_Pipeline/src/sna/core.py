"""Leakage-safe, Yelp/business-specific data and prompt builders."""
import csv, hashlib, json, os, random, tempfile
from collections import defaultdict
from datetime import datetime
from pathlib import Path


def digest(x):
    return hashlib.sha256(x.encode('utf-8')).hexdigest()


def atomic_write(path, content):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.tmp_')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='') as f: f.write(content)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


def json_write(path, obj): atomic_write(path, json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


def csv_read(path):
    with open(path, encoding='utf-8-sig', newline='') as f: return list(csv.DictReader(f))


def csv_write(path, rows, fields):
    import io
    out=io.StringIO(); w=csv.DictWriter(out, fieldnames=fields, extrasaction='ignore'); w.writeheader(); w.writerows(rows)
    atomic_write(path, out.getvalue())


def load_raw(cfg, root=None):
    d=cfg['data']; base=Path(root) if root else Path.cwd(); rows=csv_read(base/d['interactions']); items=csv_read(base/d['items'])
    for cols, source in [(('user_id','item_id','review_id',d['review_column']), rows), (('item_id','name','city','categories'), items)]:
        if not source or not set(cols).issubset(source[0]): raise ValueError('Missing required CSV columns: '+str(cols))
    ids=[x['review_id'] for x in rows]
    if len(set(ids))!=len(ids) or any(not x for x in ids): raise ValueError('Duplicate/empty review_id. Deduplicate/reconcile before splitting.')
    itemids=[x['item_id'] for x in items]
    if len(itemids)!=len(set(itemids)): raise ValueError('Duplicate item metadata IDs')
    unknown=set(x['item_id'] for x in rows)-set(itemids)
    if unknown: raise ValueError(f'Missing item metadata for {len(unknown)} items')
    return rows, {x['item_id']:x for x in items}


def create_split(cfg, root):
    rows,_=load_raw(cfg,root)
    output=root/cfg['paths']['output']/ 'splits'; output.mkdir(parents=True,exist_ok=True)
    if (output/'split_manifest.json').exists(): raise RuntimeError('Existing split manifest. Refusing overwrite: use a clean output directory for a new split.')
    split=cfg['split']; valid=float(split['valid_ratio']); test=float(split['test_ratio'])
    if valid<0 or test<0 or valid+test>=1: raise ValueError('Invalid fractions')
    grouped=defaultdict(list)
    for r in rows: grouped[r['user_id']].append(r)
    timestamp_col=cfg['data'].get('timestamp_column','timestamp')
    temporal=split['policy']=='user_temporal_if_available'
    if split['policy'] not in ('user_temporal_if_available','user_random'): raise ValueError('Unknown split policy')
    if temporal:
        try:
            for r in rows: datetime.fromisoformat(r[timestamp_col].replace('Z','+00:00'))
        except (KeyError,ValueError,TypeError) as e:
            raise ValueError('Temporal split requested but timestamps missing/unparseable; set policy=user_random explicitly if justified') from e
    rnd=random.Random(int(split['seed']))
    assigned={}
    for user in sorted(grouped):
        grp=grouped[user][:]
        if temporal: grp.sort(key=lambda x:(x[timestamp_col],x['review_id']))
        else: rnd.shuffle(grp)
        n=len(grp); nt=int(n*test); nv=int(n*valid)
        # For short histories preserve at least one train record.
        for j,r in enumerate(grp):
            assigned[r['review_id']]=('test' if j>=n-nt and nt else 'valid' if j>=n-nt-nv and nv else 'train')
    data=[dict(r,split=assigned[r['review_id']]) for r in rows]
    for kind in ('train','valid','test'):
        csv_write(output/f'{kind}.csv', [r for r in data if r['split']==kind], list(data[0].keys()))
    manifest={ 'policy':split['policy'], 'seed':split['seed'], 'counts':{k:sum(x['split']==k for x in data) for k in ('train','valid','test')}, 'raw_interactions_sha256':hashlib.sha256((root/cfg['data']['interactions']).read_bytes()).hexdigest(), 'raw_items_sha256':hashlib.sha256((root/cfg['data']['items']).read_bytes()).hexdigest(), 'review_membership':{x['review_id']:x['split'] for x in data}}
    json_write(output/'split_manifest.json',manifest)
    return manifest


def get_splits(cfg, root):
    p=root/cfg['paths']['output']/'splits'
    m=json.loads((p/'split_manifest.json').read_text())
    rows={s:csv_read(p/f'{s}.csv') for s in ('train','valid','test')}
    # Fail if raw source changes after split.
    for source,attr in [('interactions','raw_interactions_sha256'),('items','raw_items_sha256')]:
        h=hashlib.sha256((root/cfg['data'][source]).read_bytes()).hexdigest()
        if h!=m[attr]: raise ValueError(f'Raw {source} changed after split; refuse to proceed')
    memberships=m['review_membership']
    for s,rs in rows.items():
        for r in rs:
            if memberships.get(r['review_id'])!=s: raise ValueError('Split membership mismatch')
    all_ids=[r['review_id'] for rs in rows.values() for r in rs]
    if set(all_ids)!=set(memberships) or len(all_ids)!=len(set(all_ids)): raise ValueError('Split records missing/duplicate')
    return rows, m


def audit(cfg,root):
    rows,m=get_splits(cfg,root)
    train={r['review_id'] for r in rows['train']}
    heldout={r['review_id'] for s in ('valid','test') for r in rows[s]}
    if train & heldout: raise ValueError('Leakage: overlap')
    checked=0
    p=root/cfg['paths']['output']/'prompt_manifests'
    for k in ('item','user'):
        f=p/f'{k}.jsonl'
        if f.exists():
            for line in f.read_text(encoding='utf-8').splitlines():
                if not line.strip(): continue
                entry=json.loads(line); ids=set(entry['source_review_ids']); checked+=1
                if not ids<=train: raise ValueError(f'LEAKAGE {k}/{entry["entity_id"]}: non-train review')
                if ids & heldout: raise ValueError('LEAKAGE: held-out review in prompt')
    return {'split_counts':m['counts'],'audited_prompt_records':checked,'train_only_source_check':'PASS'}


def build_prompts(cfg,root,kind):
    rows,_=get_splits(cfg,root)
    train=rows['train']
    items=load_raw(cfg,root)[1]
    reviewcol=cfg['data']['review_column']
    out=[]
    if kind=='item':
        by_item=defaultdict(list)
        for x in train: by_item[x['item_id']].append(x)
        limit=cfg['llm'].get('max_input_reviews_per_item')
        for iid in sorted(by_item):
            evidence=sorted(by_item[iid],key=lambda x:x['review_id'])
            if limit is not None: evidence=evidence[:int(limit)]
            meta=items[iid]
            basic={k:(meta[k] or 'None') for k in ('name','city','categories')}
            text='BASIC INFORMATION: \n'+json.dumps(basic,ensure_ascii=False)+'\nUSER FEEDBACK: \n'+json.dumps([r[reviewcol] for r in evidence],ensure_ascii=False)
            out.append({'entity_id':iid,'kind':'item','prompt':text,'source_review_ids':[r['review_id'] for r in evidence]})
    elif kind=='user':
        by_user=defaultdict(list)
        for x in train: by_user[x['user_id']].append(x)
        limit=cfg['llm'].get('max_input_interactions_per_user')
        for uid in sorted(by_user):
            evidence=sorted(by_user[uid],key=lambda x:x['review_id'])
            if limit is not None: evidence=evidence[:int(limit)]
            lst=[]
            for r in evidence:
                path=root/cfg['paths']['output']/'profiles'/'items'/f'{digest(r["item_id"])}.json'
                if not path.exists(): raise RuntimeError(f'Missing generated item profile for {r["item_id"]}; run all item profiles first')
                record=json.loads(path.read_text(encoding='utf-8'))
                if record.get('entity_id')!=r['item_id']: raise ValueError('Profile ID/hash mismatch')
                lst.append({'title':items[r['item_id']]['name'],'description':record['profile']['summarization'],'review':r[reviewcol]})
            prompt='PURCHASED BUSINESSES: \n'+json.dumps(lst,ensure_ascii=False)
            out.append({'entity_id':uid,'kind':'user','prompt':prompt,'source_review_ids':[r['review_id'] for r in evidence]})
    else: raise ValueError('kind must be user or item')
    trainids={r['review_id'] for r in train}
    for p in out:
        if not set(p['source_review_ids'])<=trainids: raise AssertionError('train-only invariant')
    return out


def parse_profile(text):
    x=text.strip()
    if x.startswith('```'):
        x=x.split('\n',1)[1].rsplit('```',1)[0].strip()
    val=json.loads(x)
    if not isinstance(val,dict) or not isinstance(val.get('summarization'),str) or not isinstance(val.get('reasoning'),str): raise ValueError('Missing summarization/reasoning JSON string fields')
    return {'summarization':val['summarization'], 'reasoning':val['reasoning']}
