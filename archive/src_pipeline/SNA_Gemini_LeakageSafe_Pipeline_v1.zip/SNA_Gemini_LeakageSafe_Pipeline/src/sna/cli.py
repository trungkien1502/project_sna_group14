"""Command-line interface. Run python -m sna.cli ... with PYTHONPATH=src."""
import argparse, csv, json, os, sys, time
from datetime import date
from pathlib import Path
from .core import audit, atomic_write, build_prompts, create_split, csv_write, digest, get_splits, json_write, parse_profile


def main():
    p=argparse.ArgumentParser()
    p.add_argument('command',choices=['split','audit','profiles','export','status'])
    p.add_argument('--config',default='configs/config.json');p.add_argument('--kind',choices=['item','user']);p.add_argument('--mode',choices=['dry-run','live'],default='dry-run');p.add_argument('--limit',type=int)
    a=p.parse_args();root=Path(__file__).resolve().parents[2];cfg=json.loads((root/a.config).read_text());out=root/cfg['paths']['output']
    if cfg['dataset_type']!='yelp_business':raise RuntimeError('Only yelp_business prompt schema implemented; adapt before using other datasets')
    if a.command=='split': print(json.dumps(create_split(cfg,root),indent=2)[:2000]);return
    if a.command=='audit': print(json.dumps(audit(cfg,root),indent=2));return
    if a.command=='profiles':
        if not a.kind:p.error('--kind required')
        print('Preflight audit:',audit(cfg,root))
        prompts=build_prompts(cfg,root,a.kind)
        system=(root/'prompts'/f'{a.kind}_system_prompt.txt').read_text()
        signature=digest(system+json.dumps(cfg['llm'],sort_keys=True))
        pending=[]
        for rec in prompts:
            path=out/'profiles'/('items' if a.kind=='item' else 'users')/f'{digest(rec["entity_id"])}.json'
            rec['path']=str(path);rec['prompt_sha256']=digest(rec['prompt']);rec['system_sha256']=digest(system)
            if path.exists():
                saved=json.loads(path.read_text())
                if saved.get('prompt_sha256')!=rec['prompt_sha256'] or saved.get('generation_signature')!=signature: raise ValueError('Existing profile generated with different prompt/config; use fresh output directory')
                continue
            pending.append(rec)
        if a.limit is not None:pending=pending[:a.limit]
        print(f'{a.kind}: {len(prompts)} entities, {len(pending)} selected new requests, mode={a.mode}')
        if a.mode=='dry-run':
            preview=[{'entity_id':r['entity_id'],'prompt':r['prompt'],'source_review_ids':r['source_review_ids']} for r in pending]
            json_write(out/f'preview_{a.kind}.json',preview)
            print('Saved local preview only; NO API CALLS');return
        if os.environ.get('GEMINI_API_KEY') is None: raise RuntimeError('Set GEMINI_API_KEY environment variable')
        if os.environ.get('SNA_ALLOW_REMOTE_LLM')!='YES':raise RuntimeError('Explicit opt-in required: set SNA_ALLOW_REMOTE_LLM=YES after data privacy and budget check')
        from google import genai
        from google.genai import types
        client=genai.Client(api_key=os.environ['GEMINI_API_KEY'])
        statepath=out/'llm_usage_state.json'
        state=json.loads(statepath.read_text()) if statepath.exists() else {'day':str(date.today()),'requests':0}
        if state['day']!=str(date.today()):state={'day':str(date.today()),'requests':0}
        maxreq=int(cfg['llm']['daily_request_cap']);gap=float(cfg['llm']['minimum_interval_seconds']);last=0
        manifestpath=out/'prompt_manifests'/f'{a.kind}.jsonl'; manifestpath.parent.mkdir(parents=True,exist_ok=True)
        for rec in pending:
            if state['requests']>=maxreq:print('Daily request cap reached; stop safely');break
            delta=time.monotonic()-last
            if last and delta<gap: time.sleep(gap-delta)
            try:
                response=client.models.generate_content(model=cfg['llm']['model'],contents=rec['prompt'],config=types.GenerateContentConfig(system_instruction=system,temperature=cfg['llm']['temperature'],max_output_tokens=cfg['llm']['max_output_tokens']))
                last=time.monotonic()
                state['requests']+=1
                json_write(statepath,state)
                text=response.text or ''
                parsed=parse_profile(text)
            except Exception as e:
                print('STOP: API or profile parsing failure:',type(e).__name__,str(e)[:250]);break
            meta=getattr(response,'usage_metadata',None)
            record={'entity_id':rec['entity_id'],'kind':a.kind,'profile':parsed,'llm_model_requested':cfg['llm']['model'],'generation_signature':signature,'prompt_sha256':rec['prompt_sha256'],'system_sha256':rec['system_sha256'],'source_review_ids':rec['source_review_ids'],'usage':{'prompt_tokens':getattr(meta,'prompt_token_count',None),'candidate_tokens':getattr(meta,'candidates_token_count',None),'total_tokens':getattr(meta,'total_token_count',None)}}
            json_write(rec['path'],record)
            # Append with fsync on each successful completion; fail-closed audit can detect any orphaned record.
            with open(manifestpath,'a',encoding='utf-8') as f:
                f.write(json.dumps({'entity_id':rec['entity_id'],'source_review_ids':rec['source_review_ids'],'prompt_sha256':rec['prompt_sha256']},ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
            print('Saved',a.kind,rec['entity_id'],'usage',record['usage'])
        print('Postflight:',audit(cfg,root))
        return
    if a.command=='export':
        print('Preflight:',audit(cfg,root))
        for kind,sub in [('item','items'),('user','users')]:
            records=[]
            for path in sorted((out/'profiles'/sub).glob('*.json')):
                x=json.loads(path.read_text(encoding='utf-8'))
                records.append({'entity_id':x['entity_id'],'summarization':x['profile']['summarization'],'reasoning':x['profile']['reasoning'],'model':x['llm_model_requested'],'source_review_ids_json':json.dumps(x['source_review_ids'])})
            csv_write(out/'exports'/f'{kind}_profiles.csv',records,['entity_id','summarization','reasoning','model','source_review_ids_json'])
            print(kind,len(records),'exported')
        return
    if a.command=='status':
        print('Audit:',audit(cfg,root))
        for sub in ('items','users'):print(sub,len(list((out/'profiles'/sub).glob('*.json'))))
        state=out/'llm_usage_state.json'
        if state.exists():print('Local request count:',state.read_text())

if __name__=='__main__':main()
