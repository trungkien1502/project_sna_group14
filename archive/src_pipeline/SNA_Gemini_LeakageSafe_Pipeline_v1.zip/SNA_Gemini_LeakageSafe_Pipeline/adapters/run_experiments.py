"""Fail-closed interface until actual team scripts are mapped and audited."""
import csv
from pathlib import Path
p=Path(__file__).with_name('EXPERIMENT_MAPPING.csv')
rows=list(csv.DictReader(p.open()))
missing=[r['experiment'] for r in rows if r['verified']!='YES' or not r['existing_script']]
if missing:raise SystemExit('BLOCKED: experimental adapters not yet verified: '+', '.join(missing))
raise SystemExit('Mappings filled: implement explicit command runner + checksums before actual training')
