# Colab instructions

1. Upload/unzip this folder to Google Drive. Keep raw data access private and use a mounted folder; Colab runtime storage is ephemeral.
2. `!pip install -q google-genai pytest`
3. `%cd /content/drive/MyDrive/SNA_Gemini_LeakageSafe_Pipeline` (adjust actual path)
4. `!python run.py split` and `!python run.py audit`
5. `!python run.py profiles --kind item --mode dry-run --limit 2` — inspect outputs/preview_item.json; it does **not** send text outside Colab.
6. From Colab Secrets use `from google.colab import userdata; import os; os.environ['GEMINI_API_KEY']=userdata.get('GEMINI_API_KEY')`. Do not print secret.
7. `os.environ['SNA_ALLOW_REMOTE_LLM']='YES'` only after verifying dataset privacy, Free Tier billing, and prompt previews.
8. `!python run.py profiles --kind item --mode live --limit 10` then inspect profiles; *all items must complete before starting user profile step*.
9. After item generation succeeds, `!python run.py profiles --kind user --mode dry-run --limit 2` and then live in daily quota-limited batches.
10. `!python run.py audit`, `!python run.py export`, `!python run.py status`.

**Do not attempt to use `run_experiments.py` until E1–E4 source scripts/configs are integrated.**
