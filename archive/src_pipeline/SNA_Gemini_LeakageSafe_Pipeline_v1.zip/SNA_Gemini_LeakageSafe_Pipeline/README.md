# SNA Group 14 — Leakage-Controlled LLM Replacement Pipeline (starter v1)

**Goal:** Rebuild semantic profiles from original raw reviews using a different LLM, then prepare a fresh RLMRec-Con training run and *your original* E1–E4 experiments. This starter does **not** pretend to include the group's uninspected experimental scripts or ready-to-run RLMRec-Con integration.

## Critical design decision

Data are split at the **interaction/review level BEFORE profile creation**. Both item feedback and user histories are drawn **exclusively from `train`**. This is a defensible leakage-controlled variant; it cannot prove the original authors used the same split policy because their released example scripts do not document the full prompt-construction pipeline.

The original RLMRec repository's example scripts use `gpt-3.5-turbo`, one example prompt per request, and the item/user system prompt texts included here for the Yelp/business setting. Their public scripts demonstrate one prompt, not the entire dataset generation process.

## Required raw inputs

Place **your own raw data** under `data/raw/` (none shipped in ZIP). Default CSV contracts:

- `interactions.csv`: `user_id,item_id,review_id,review_text,timestamp` (timestamp optional). One row per review/interaction, with unique `review_id`. Avoid privacy-sensitive text if provider data rules do not allow upload.
- `items.csv`: `item_id,name,city,categories` (business/Yelp setting). Static metadata only: no test-derived aggregate features. For another dataset, adapt the contract and prompts rather than mislabelling fields.

No supplied dataset is automatically copied, split, or uploaded.

## Quickstart (local/Colab)

```bash
pip install -r requirements.txt
# Put original raw files under data/raw/
python run.py split --config configs/config.json
python run.py audit --config configs/config.json
python run.py profiles --config configs/config.json --kind item --mode dry-run --limit 2
python run.py profiles --config configs/config.json --kind item --mode live --limit 10
python run.py profiles --config configs/config.json --kind user --mode live --limit 10
python run.py export --config configs/config.json
python run.py status --config configs/config.json
```

Before `live`, set `GEMINI_API_KEY` in environment/Colab Secrets. Do **not** enter keys into repo source, logs, or notebook cells. Free-tier capacity is provider-specific and is not guaranteed. The code limits daily requests, stops on 429, and never automatically switches to a paid provider.

## Pipeline

1. `split` — create immutable row-level manifest with train/valid/test memberships, fingerprints, and dataset metadata (default: deterministic per-user temporal if all timestamps valid; else seeded random per-user). **For strict reproduction set split policy to original paper/group split instead.**
2. `audit` — verify splits are disjoint, review IDs unique, source IDs of all generated prompts belong only to train.
3. `profiles --kind item` — construct original Yelp-style `BASIC INFORMATION` / `USER FEEDBACK` prompts using train reviews **only**; generate item profiles using original system instruction; save one JSON response per item with traceable source IDs and hashes.
4. `profiles --kind user` — construct `PURCHASED BUSINESSES` prompts from train interactions, linking to freshly generated train-only item profiles; generate one user profile per request.
5. `export` — create item/user profile tables, provenance manifests, and empty training/experiment interface instructions.
6. `adapters/` — connect the exact source code, model configs, splits, checkpoints and evaluator used by your group in E1/E2/E3A–E3D/E4. **This starter intentionally refuses to fake results or to train a substitute model.**

## Leakage policy

- Only train review/interaction rows may enter a prompt, regardless of user or item.
- `valid`/`test` rows are never used for profile extraction; metadata may be used only if it is independent of held-out behavior.
- Profile prompt manifests store every review ID; run `audit` before and after generation.
- `--mode dry-run` writes prompt-preview to local disk; use it to inspect before any paid/free remote calls.
- If reviews/timestamps or split files originally used by the authors are unavailable, report this as a **reproduction limitation** rather than asserting identity with original paper.
- The model's generated item profile is permitted in user prompts only after the item profile was built from train-only evidence.
- To avoid contamination, no published GPT-3.5 profile files enter this new generation path.

## Experiment reintegration

Edit `adapters/EXPERIMENT_MAPPING.csv` after inspecting the group's real scripts. The sample `adapters/run_experiments.py` only checks that commands are configured; it is a deliberate **fail-closed** interface. Training, embeddings, E1–E4 metrics are not implemented by this audit/profile starter.

Embeddings must use the intended original embedding model and text field (e.g. `summarization`) as verified from the group code. If that embedding endpoint is unavailable for free, document the additional model change; do not claim a single-variable experiment.

## Run artefacts

- `outputs/splits/*.csv` and `split_manifest.json`
- `outputs/profiles/items/*.json`, `outputs/profiles/users/*.json`
- `outputs/prompt_manifests/*.jsonl`
- `outputs/exports/{item,user}_profiles.csv`
- `outputs/run_status.json`

All outputs are written atomically. On resume, successful records are skipped. This first version is sequential; it does not promise days-long unattended Colab execution.

## Source references

- https://github.com/HKUDS/RLMRec
- https://github.com/HKUDS/RLMRec/tree/main/generation

**Known gaps**: original full generation data-preparation scripts not verified in released example; exact original split policy and source row selection not verified; group E1–E4 scripts not imported; original downstream embedding/training adapter not integrated; quota/billing for Gemini must be checked in Google AI Studio.
