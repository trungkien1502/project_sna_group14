# Báo cáo kỹ thuật — Rebuild SNA Group 14 Pipeline v2 (Amazon-book)

**Ngày đối chiếu nguồn:** 21/11/2026. **Phạm vi:** GitHub RLMRec, GitHub nhóm, cấu trúc Google Drive và một số QA artifacts. **Không chạy training/API thật trong môi trường xây ZIP.**

## 1. Chính xác yêu cầu cần phục vụ

- Giữ đúng Amazon-book đã dùng ở E1–E4, **không chia lại** trn/val/tst; giữ user/item ID nội bộ.
- Xây lại item/user semantic profiles **từ văn bản raw metadata/reviews**, không sử dụng tác giả GPT-3.5 profiles làm nguyên liệu của Gemini.
- Sử dụng hướng dẫn prompt Amazon được công khai, minh bạch phần payload reconstruction và việc sampling mà tác giả chưa công bố.
- Tạo embeddings mới, đóng gói đúng 7 pickles rồi huấn luyện RLMRec-Con/LightGCN với pipeline E1–E4 nhóm đã thực sự xây dựng.
- Chống leakage ở khâu xây LLM prompt và bảo vệ Train/Val/Test; log nguồn cặp tương tác của review được sử dụng.
- Duy trì baseline/outputs cũ, bảo toàn nghiên cứu, tránh lẫn run Gemini với author output.

## 2. Kết quả đối chiếu nguồn

| Source | Source pinned | Vai trò |
|---|---|---|
| `HKUDS/RLMRec` | `22413752246de3dee8ab0d509f7f7a8889080f95` | Amazon prompts, mappers, LightGCN, RLMRec-Con, trainer, metrics, YAML |
| `trungkien1502/project_sna_group14` | `c17caeb4448a8add7939510411339af918d258bb` | 24 notebooks, `src/inference/export_topk.py`, E1–E4 protocol |
| `Data_SNA_Group14/data/raw/amazon` on Drive | 7 `.pkl` files | 3 processed split matrices + 2 author profiles + 2 author semantic embeddings |
| Drive historical E3C | `E3C_export_status.csv` | 12 `export_passed` + 3 `reused_E1_passed` |
| Drive historical E4 | `E4_topk_inventory_QA.csv` | 18 entries with status PASS; analysis manifest `QA_PASS_18_OF_18` |

**Critical finding:** Neither the RLMRec repo nor the inspected group Drive's 7 file collection supply all original per-book title/description/review-text records in the same files. The author's RLMRec mapper bridges `iid` ⇄ `asin` and `uid` ⇄ `reviewerID`. Raw Amazon text must be separately acquired and coverage/join verified; the source provenance may be partial if the raw release differs from the one the authors processed.

**Critical uncertainty:** Public `generation/item/generate_profile.py` and `generation/user/generate_profile.py` are **Yelp demos** with randomly picked prompt examples, not full Amazon-book generation scripts. Published Amazon instructions have been copied verbatim to this ZIP, with a reconstructed item/user payload builder. **No evidence here to conclude author prompts definitely did or did not use val/test**.

## 3. Workflow implemented

```text
Original Amazon-book: trn_mat.pkl + val_mat.pkl + tst_mat.pkl (IMMUTABLE)
        + HKUDS/RLMRec mapper/amazon_user.json, amazon_item.json
        + EXTERNAL raw Amazon book metadata + reviews (MUST SUPPLY)
      -> split/mapping audit & sha256
      -> stream/join raw texts; train-positive pair filtering & ambiguity report
      -> exact AMAZON item system prompt + frozen item user-payload builder
      -> Gemini items (9332) + per-prompt provenance
      -> exact AMAZON user system prompt + train-only history + NEW item summaries
      -> Gemini users (11000) + per-prompt provenance
      -> embeddings (only profile summarization, row indices 0..N-1)
      -> NEW 7-file RLMRec directory, original splits byte-identical
      -> isolated RLMRec + Group14 notebook working copies
      -> E1 → E1 Top-K / Most Popular → E2
                          → E3A → E3B → E3C / E3D
                          → E4 recovery training / export / analysis
```

## 4. Source-to-stage mapping and files

- E1: `03_E1_Full_Training.ipynb` for `lightgcn`/`lightgcn_plus` × seeds `[2023,2024,2025]`; `04_E1_Export_TopK.ipynb` + `src/inference/export_topk.py`; `05_E1_Most_Popular.ipynb`; `06_E1_Summary.ipynb`.
- E2: `07_E2_Popularity_Bias.ipynb` consumes 7 TopK sets and train/test, creates ARP/APLT/head/tail/exposure outputs.
- E3A: `08_E3A_Semantic_Alignment_Ablation_FIXED.ipynb` for user-only and item-only, 3 seeds each; graph-only = E1 LightGCN; full alignment = E1 lightgcn_plus for downstream comparisons.
- E3B: `10_E3B_Popularity_Bias_Analysis.ipynb`; full E1 TopK + E3A two ablations + E2 reference.
- E3C: `11_E3C_Semantic_Weight_Sensitivity_FIXED_v3.ipynb` (weights 0/.005/.02/.05 ×3); weight .01 reuses E1 **same new profile branch**; `E3C_Export_TopK_Fixed.ipynb`; `12_E3C_Analysis_Weight_Sensitivity.ipynb` with previous fixed baseline constant **automatically patched using NEW E1 metrics**.
- E3D: `E3D_Semantic_Collaborative_Agreement_Drive.ipynb` consumes new semantic embedding file pair, as well as E1/E3A TopK.
- E4: `E4_RQ3_Training_FIXED_Drive_Checkpoints.ipynb` 2 models × depth 1,2,3 ×3 seeds; `E4_RQ3_Export_TopK_FIXED.ipynb` exports from `recovery_runs/`, not older `runs/`; `E4_RQ3_Analysis.ipynb` evaluates 18 TopK.

**Source repository issues accounted for:** the group's `README.md` is only 44 bytes; `docs/EXPERIMENT_SPEC.md` describes older/draft paths absent in current GitHub; obsolete notebook variants were **not** selected as canonical; `E4_RQ3_Evaluation_Analysis_SAFE.ipynb` referenced in handoff is absent in current main tree.

## 5. Data leakage policy and exactly what it can prove

- Train, Val, Test matrices are **never repartitioned**; audit checks shape, counts, pair-wise intersections, source checksums.
- Item prompts are made from public/static book title and description, not review text. Missing desc gets `"None"`; this is one documented policy choice (the paper narrative mentions other possible fallback information, but the released Amazon item instruction is title + description).
- User prompts may see only train pairs `(uid,iid)`, their title, the corresponding new item-profile summary, and review text joined from mapped raw Amazon only when the pair occurs in train. Any raw review of a nontrain pair is discarded before the user prompt is built.
- Duplicated source reviews for the **same train pair** are omitted, because author matrices do not tell which individual review event belongs to their dataset/split.
- **Limit:** Pair-based filtering cannot provide definitive event-level leakage certification. Even one review for a `(uid,iid)` train pair may correspond to a different raw review event/time in another split. To assert stronger provenance, acquire original event-level split IDs or restrict user prompt `review` to `"None"` with a separately documented data policy.
- Generated profiles are stored with prompt hashes and source IDs. E1 E3/E4 TopK train-positive masking remains a different QA check, and is **not** substituted for LLM input leakage proof.

## 6. Embedding science and interpretation

RLMRec author example `generation/emb/generate_emb.py` encodes `summarization` using `text-embedding-ada-002`; this produces the 1536-dimension released embeddings. Group training code obtains `usr_emb_np.pkl`, `itm_emb_np.pkl` from RLMRec configurator even for LightGCN, and `lightgcn_plus.py` uses semantic embeddings for alignment.

- To compare LLM generation methods under a consistent embedding encoder: choose `embedding.provider=openai`, `text-embedding-ada-002`; however API cost/availability may apply.
- To run a zero-embedding-API-cost pilot choose local `all-MiniLM-L6-v2`. **Do not claim LLM alone explains accuracy/bias differences**, since semantic encoder also changes.
- New profile IDs and embedding rows must match 11k/9332 indices. `package` refuses mixed user/item dimensions and identical old embedding SHA.

## 7. Test evidence (on 2026-11-21)

Command executed successfully:

```bash
PYTHONPATH=. python -m unittest discover -s tests -v
```

**12/12 PASS** using 3 synthetic users/4 synthetic books (NOT actual Amazon/Gemini/GPU):

1. Existing source split preserved, train/val/test counts and disjointness.
2. Raw review text from held-out pairs absent from train review index.
3. Exact AMAZON prompt generation for item→user, new item summaries used.
4. Mock LLM output validation as JSON and resumable profile persistence.
5. Mock embedding shape/row IDs, seven file RLMRec package with byte-identical split copies.
6. Refuse mock artifacts as real training inputs.
7. Lock prompt hashes; reject modifications and split overlaps.
8. Original notebook unchanged after staged model/seed/root rewriting.
9. Per-run configuration lock rejects changing Gemini model without a fresh run ID.
10. Optional no-review user prompt mode excludes all review text.
11. Safe run-all preview enumerates all 34 stage invocations without training.
12. Runtime exporter copy patches old Drive root without touching original group Git checkout.

**No actual Gemini request was made. No new GPU model has been trained.** The `run-all` scheduler and `nbclient` bridges have been code-reviewed but not end-to-end tested on Colab; runtime errors can occur and will be recorded without faking outputs.

## 8. Gaps before claiming full completion

| Gate | Status | Evidence needed |
|---|---|---|
| Exact Amazon raw text source/vintage | **BLOCKED** | Raw metadata+reviews file paths and source checksum; coverage ≥ chosen threshold; sample ID/review join audit |
| Train-event-level review provenance | **PARTIALLY VERIFIABLE** | Original event split IDs, or explicitly accept pair-level filtering and its limitation |
| Real Gemini pilot and full profiles | **NOT EXECUTED** | Profile JSONs; API usage; parse QA |
| Real semantic encoder | **NOT EXECUTED** | Embeddings n_users × dim and n_items × dim, provenance |
| Colab E1–E4 new branch | **NOT EXECUTED** | New checkpoint, TopK QA, E2/E3/E4 summary, reports |
| Effect attribution | **CONDITIONAL** | Keep embedding fixed where possible; disclose unknown old prompt-split policy |

**Honest release status:** This ZIP is a working Amazon-book **data-to-profile-to-export implementation** and a source-specific **E1–E4 orchestration bridge**. It is **not a finished experimental result** until the real raw data, Gemini, embedding, and GPU stages pass in the user's environment. No current group data or existing results have been modified by the creation of this ZIP.
