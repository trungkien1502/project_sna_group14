# Validation log — 2026-11-21

Command: `PYTHONPATH=. python -m unittest discover -s tests -v`

**Result: 12 tests passed; 0 failed.**

| Test | Outcome |
|---|---|
| Original train/val/test pair split audit | PASS |
| Rejection of held-out raw reviews | PASS |
| End-to-end offline mock profile → embedding → 7-file package | PASS |
| Refusal to package mock as production | PASS |
| Split overlap detection | PASS |
| Prompt hash immutability | PASS |
| Strict JSON output validation | PASS |
| Repeatable seeded train-history subsample | PASS |
| Explicit raw review provenance limitation | PASS |
| Run config LLM/model changes rejected | PASS |
| Optional review-free user prompt variant | PASS |
| Staged notebook model/seed/root rewrite, original unchanged | PASS |
| Staged group exporter original unchanged | PASS |
| 34-invocation run-all plan-only safety | PASS |

Test framework counts 12 methods; some rows above are sub-assertions within a method. Synthetic fixtures only: 3 users, 4 items. No actual API/GPU experiment was performed.

**Source audit:** HKUDS/RLMRec and Group14 commit SHAs pinned as specified; file identities and E3C/E4 historical QA artifacts checked through connected GitHub and Drive. Historical `PASS` is not proof that this new pipeline has run E1–E4 successfully.

**Current blockers to new experimental results:** missing external raw Amazon book metadata/reviews inside the current project folder; live model/API and embeddings unexecuted; new GPU model checkpoints unavailable.
