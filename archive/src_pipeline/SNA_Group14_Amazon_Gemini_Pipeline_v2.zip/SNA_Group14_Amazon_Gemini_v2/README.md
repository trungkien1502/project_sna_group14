# SNA Group 14 — Amazon-book LLM profile pipeline v2

**Version:** 2.0.0, built 2026-11-21  
**Repository audited:** `HKUDS/RLMRec` `22413752246de3dee8ab0d509f7f7a8889080f95`; `trungkien1502/project_sna_group14` `c17caeb4448a8add7939510411339af918d258bb`.  
**Dataset:** the **original Amazon-book processed split**, *not Yelp*.  
**Status:** **DATA/PROMPT/EXPORT OFFLINE TESTED; E1–E4 GPU/API RUNS NOT EXECUTED IN THIS DELIVERY.**

## Important: don't run the old v1

The previous `SNA_Gemini_LeakageSafe_Pipeline_v1.zip` was based on Yelp and random split: **do not use it**. The present version is rebuilt around the Group 14 code and the exact RLMRec Amazon matrices. It does not delete, overwrite, or resplit old data or outputs.

### Data sources and format

`/content/drive/MyDrive/Data_SNA_Group14/data/raw/amazon/` currently contains (confirmed on Drive):

- `trn_mat.pkl` — 11,000 x 9,332, 120,464 train positives
- `val_mat.pkl` — 40,290 validation positives
- `tst_mat.pkl` — 40,106 test positives
- `usr_prf.pkl` / `itm_prf.pkl` — old generated profiles (baseline **ONLY**)
- `usr_emb_np.pkl` / `itm_emb_np.pkl` — old embeddings (baseline **ONLY**)

**Do not use the 4 old profile/embedding files in the new profile-generation branch.** The 3 original split files are **read-only source files**; they are copied byte-for-byte into a new isolated run after QA.

The 7 released pickles **do not include the unprocessed book title/description/review-text source**. Supply external Amazon Books review + metadata JSONL or JSONL.GZ, ideally the version matching the author mapping. The README of HKUDS/RLMRec points to the [McAuley Amazon datasets](https://cseweb.ucsd.edu/~jmcauley/datasets/amazon/links.html) and ships mapper files `data/mapper/amazon_user.json` (`uid` -> `reviewerID`) and `data/mapper/amazon_item.json` (`iid` -> `asin`). Amazon metadata and reviews are **not distributed by this ZIP**. A 2014-era Amazon release may use `meta_Books.json.gz` and `reviews_Books_5.json.gz`, but **verify coverage and mapping** instead of assuming it matches author preprocessing.

## Model and embedding decisions

- The LLM is configurable. `gemini-3.5-flash-lite` is a **pilot configuration**, not an asserted scientifically optimal model.
- To isolate **LLM-only** influence relative to the author profiles, preserve the author's `text-embedding-ada-002` embedding model with `configs/amazon_v2.paper_embedding.example.json`. This requires an OpenAI key/billing and the model remaining accessible to your account. **Do not claim zero cost.**
- `configs/amazon_v2.local_embedding_pilot.example.json` uses local `sentence-transformers/all-MiniLM-L6-v2` for no per-request embedding API charge, but then both **LLM and embedding model change**. Results are a distinct experimental condition.
- An *unknown* original GPT-3.5 prompt-construction data split (train/val/test) cannot be conclusively repaired retrospectively. Strict train-only profiling is a **new documented policy**; a performance difference vs author artifacts cannot solely be attributed to Gemini if the old profiles had different input data.

## Exact commands (Colab Linux + mounted Drive, from ZIP directory)

See [`RUN_COLAB.md`](RUN_COLAB.md), [`QuickStart_Colab.ipynb`](QuickStart_Colab.ipynb).

```bash
# 0. Clone BOTH source repositories, PINNED commits, and install dependencies.
#    Edit configs/amazon_v2.example.json paths for your Drive/raw Amazon files.
python run.py --config configs/amazon_v2.example.json audit
python run.py --config configs/amazon_v2.example.json index-raw

# 1. Item profiles: ORIGINAL AMAZON instruction file; description is static metadata.
python run.py --config configs/amazon_v2.example.json build-prompts --kind item
python run.py --config configs/amazon_v2.example.json profiles --kind item --dry-run --limit 3
# Put GEMINI_API_KEY into your runtime environment privately; explicitly authorize remote calls.
python run.py --config configs/amazon_v2.example.json profiles --kind item --limit 10
# Repeat until ALL 9,332 item profiles are completed.

# 2. User profiles: train-only purchased items + generated item summary + train-pair review.
python run.py --config configs/amazon_v2.example.json build-prompts --kind user
python run.py --config configs/amazon_v2.example.json profiles --kind user --limit 10
# Repeat until ALL 11,000 user profiles are completed.

# 3. Encode only the `summarization` field; verify user/item IDs/shapes.
python run.py --config configs/amazon_v2.example.json embed --kind item
python run.py --config configs/amazon_v2.example.json embed --kind user
python run.py --config configs/amazon_v2.example.json package

# 4. Explicit run plan, checks, and OPTIONAL real GPU execution.
python run.py --config configs/amazon_v2.example.json preflight
python run.py --config configs/amazon_v2.example.json plan
python run.py --config configs/amazon_v2.example.json run-all
# Only after inspecting stage plan and costs/resources:
python run.py --config configs/amazon_v2.example.json run-all --execute
```

**Environment keys:** `GEMINI_API_KEY` and `SNA_ALLOW_REMOTE_LLM=YES` required for actual LLM calls; `OPENAI_API_KEY` and `SNA_ALLOW_REMOTE_EMBEDDING=YES` required for original ADA embedding. Never commit keys or paste them in notebooks. The local daily cap is only a user-side guard, **not Google's official remaining quota**. Long executions must be rerun manually after Colab sessions disconnect; no continuous background job is implied.

## Split protocol, prompt provenance and leakage checks

1. `audit` loads the three **original** matrices and verifies shape, nonzero counts, disjoint train/val/test pairs and SHA256 of matrices + mapper files. No resplit.
2. `index-raw` streams unprocessed book metadata/reviews, links `asin` and `reviewerID` to original row IDs, records source SHA256, rejects **all reviews whose user-item pair is not in train**, and **omits ambiguous duplicate source reviews**. Config `profiles.user_review_policy="none"` omits *all* raw reviews for a stricter no-review variant. This is a pair-level train gate, **not a proof of original review event membership** (author matrices do not encode raw review IDs).
3. `build-prompts --kind item`: exact published Amazon item **system instruction** plus a clearly marked reconstructed body with `title`, `description`. No reviews in item prompt by default; when description is missing use `"None"`, without uncontrolled fallback review collection.
4. `build-prompts --kind user`: exact published Amazon user **system instruction**, item-profile `summarization`, book title, and user review only when its pair is in train; otherwise `"None"`. Freeze a deterministic subset of **up to 20** train items via SHA256(seed,user,item). **The paper does not publish an exact per-user sampling number or full prompt builder**; `20` is an explicit experimental choice, not an alleged paper value.
5. Every saved prompt includes system hash, full text and ID-level provenance. Existing prompts with changed hashes **cannot be silently overwritten**. Each returned profile stores model, prompt hash and usage; generation resumes by checking saved files.
6. Only `summarization` is embedded, matching the example in `generation/emb/generate_emb.py`.
7. `package` produces exactly seven files under `<run_root>/<run_id>/data/raw/amazon/`; original split bytes are preserved and the other four are generated NEW. It refuses mock profiles or mock embeddings in real runs. All inputs are hashed in `package_manifest.json`.
8. `preflight` checks package hashes, split parity and pinned commits; group notebooks are run only from **isolated staged copies**, with old Drive root rewritten to this new run directory.

**Important limitation:** The original author's Amazon prompt construction script and event-level review-to-train split are not public. Passing the pair-level gate and Top-K ranking-mask checks does not prove the old author profiles were train-only. It documents a stricter new protocol.

## Notebook-to-stage map (user repository only; no invented notebooks)

| Stage | Source notebook(s) | Output dependency |
|---|---|---|
| E1 train | `03_E1_Full_Training.ipynb`, each model×seed | RLMRec `train_encoder.py`, checkpoint + metrics |
| E1 Top-K | `04_E1_Export_TopK.ipynb` + `src/inference/export_topk.py` | Verified E1 checkpoint |
| E1 Most Popular | `05_E1_Most_Popular.ipynb` | Train/test matrix |
| E1 summary | `06_E1_Summary.ipynb` | E1 model and Most Popular metrics |
| E2 | `07_E2_Popularity_Bias.ipynb` | 7 E1/MP Top-K, train/test |
| E3A | `08_E3A_Semantic_Alignment_Ablation_FIXED.ipynb` | E1 full/graph references, user/item-only own 6 runs |
| E3B | `10_E3B_Popularity_Bias_Analysis.ipynb` | E1 full, E3A user/item, E2 metrics |
| E3C train | `11_E3C_Semantic_Weight_Sensitivity_FIXED_v3.ipynb` | 0/.005/.02/.05 ×3 new; **.01 from new E1** |
| E3C export | `E3C_Export_TopK_Fixed.ipynb` | New E3C checkpoints + new E1 for .01 |
| E3C analysis | `12_E3C_Analysis_Weight_Sensitivity.ipynb` | 15 Top-K; expected baseline is patched from **new** E1 metrics |
| E3D | `E3D_Semantic_Collaborative_Agreement_Drive.ipynb` | NEW `usr_emb_np.pkl`, `itm_emb_np.pkl`, E1/E3A Top-K |
| E4 train | `E4_RQ3_Training_FIXED_Drive_Checkpoints.ipynb` | 2 models × 3 layers × 3 seeds, NEW `recovery_runs/` |
| E4 export | `E4_RQ3_Export_TopK_FIXED.ipynb` | 18 NEW recovery checkpoints |
| E4 analysis | `E4_RQ3_Analysis.ipynb` | 18 E4 Top-K, QA, CSV, plots |

The new wrapper uses the **original** RLMRec implementation and the group's original notebooks. It stages copies, it does not rewrite mathematical loss or metrics, and always logs source SHA256. The E3A and E4 wrappers allocate distinct clean RLMRec checkouts per run/model-layer to avoid untracked symlink contamination from earlier notebooks. Several group notebooks are Colab-specific and have not been run on this host; external `run-all --execute` can fail on dependencies, GPU, or changed upstream notebook code. It **stops on missing or unverifiable outputs instead of manufacturing PASS**.

**Not canonical:** `E3C_Colab.ipynb` (unrelated orphan agreement prototype), old E3C `11_...` without `FIXED_v3`, old E4 `13_...`, `E4_RQ3_6_Members_Training`, `E4_RQ3_Training_Choose_Model_Layer (1)`, and old E4 exporter `SAFE`; keep for provenance, never delete old work.

## Output layout

```text
Data_SNA_Group14/
  data/raw/amazon/                 # ORIGINAL; never modified
  experiments/E1|E2|E3|E3B|E3C|E3D|E4/    # ORIGINAL; never modified
  experiments_llm_v2/<run_id>/
    audit/split_audit.json
    raw_index/{books,train_reviews}.jsonl
    raw_index/index_manifest.json
    prompts/item/{0..9331}.json; prompts/user/{0..10999}.json
    profiles/item/{0..9331}.json; profiles/user/{0..10999}.json
    embeddings/item/embeddings.npy; embeddings/user/embeddings.npy
    data/raw/amazon/               # 7 .pkl files for NEW RLMRec runs
    data/package_manifest.json
    experiments/E1|E2|E3|E3B|E3C|E3D|E4/
    experiments/predictions/
    runtime/notebooks; runtime/logs; runtime/run_all_status.json
```

## How far has this delivery been verified?

- **Verified locally:** Python syntax; 12 synthetic-data unit tests validating split disjointness, train-only pair filtering, immutable prompts, mock generation, mock embedding, 7-file RLMRec-compatible package and notebook staging without editing originals.
- **Verified via connected sources:** public RLMRec paper GitHub and group GitHub filenames/code, group Drive 7 Amazon pickles, E3C 15-TopK status and E4 18/18 Top-K inventory PASS from earlier runs.
- **NOT verified:** real raw Amazon source file coverage; real 20,332 Gemini API calls; real `text-embedding-ada-002` availability and billing; real GPU training of any new branch; complete E1-E4 new metrics/QA. Any claim of complete end-to-end reproduction before these checks would be false.

Further detail: [`docs/IMPLEMENTATION_REPORT.md`](docs/IMPLEMENTATION_REPORT.md).
