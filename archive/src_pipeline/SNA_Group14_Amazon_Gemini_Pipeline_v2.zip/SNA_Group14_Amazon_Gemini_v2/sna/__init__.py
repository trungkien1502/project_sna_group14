"""Amazon-book, train-only semantic-profile generation and experiment bridge."""
__version__ = '2.0.0'
