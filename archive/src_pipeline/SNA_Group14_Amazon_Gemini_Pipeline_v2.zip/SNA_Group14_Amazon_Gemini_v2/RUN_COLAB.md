# Colab operating instructions — no silent old-data reuse

## Prepare

1. Upload and extract the v2 ZIP on Colab (or to Google Drive). Set the working directory to the extracted folder. Mount Google Drive first.
2. Clone the paper and group repositories at the two pinned commit hashes. From Colab shell:

```bash
cd /content
git clone https://github.com/HKUDS/RLMRec.git
git -C /content/RLMRec checkout 22413752246de3dee8ab0d509f7f7a8889080f95
git clone https://github.com/trungkien1502/project_sna_group14.git
git -C /content/project_sna_group14 checkout c17caeb4448a8add7939510411339af918d258bb
```

If the paper or group code is already checked out at the exact commit, use it; **do not delete or reset existing dirty working directories automatically**.

3. Edit `configs/amazon_v2.example.json`: the *absolute* Drive paths to `project_root`, `run_root`, `raw_metadata`, `raw_reviews` and both cloned repositories. Set a unique `run_id`. Do not reuse a run ID with a changed model or prompt.
4. Install requirements; original paper GPU training may need a separately validated Colab PyTorch runtime:

```bash
pip install -r requirements.txt
# for local embedding pilot only:
pip install sentence-transformers
```

**Important:** The original 7 `.pkl` files are processed release files. To generate new profiles, supply external raw Amazon **book title/description and raw review text**. The ZIP does **not** include raw text data. Before spending API quota, run `audit` and `index-raw`: a wrong Amazon release will be rejected if metadata coverage is under the configured threshold. Check `index_manifest.json` and sample records for join accuracy.

## Real Gemini calls: authorizing and testing

Never share keys with ChatGPT or commit them to the repo. In Colab Python:

```python
import os
from getpass import getpass
os.environ['GEMINI_API_KEY'] = getpass('Gemini API key: ')
os.environ['SNA_ALLOW_REMOTE_LLM'] = 'YES'
```

Start with 2–10 real item profiles; audit output (strict JSON, no hallucinations, correct titles). Proceed with the rest via repeated Colab sessions, preserving `run_root`. **Do not call the user-profile builder before all item profiles are completed.**

`profiles --limit N` creates at most N NEW profiles, skipping completed ones. All calls are 1 entity per request by default, with an adjustable local limit. The model and sampling parameters are frozen in `prompt_sha256`; changing them requires a NEW run ID.

If using the paper-matched original embedding provider, authorize separately:

```python
os.environ['OPENAI_API_KEY'] = getpass('OpenAI embedding API key: ')
os.environ['SNA_ALLOW_REMOTE_EMBEDDING'] = 'YES'
```

`text-embedding-ada-002` may have financial/availability constraints; if not available, use local embedding in a **separately labeled experiment** and do not attribute all effects solely to Gemini.

## Train E1–E4

`plan` lists the 14 source notebook stages. `run-all` produces a 34-step plan of notebook invocations and output status, **without training**. `run-all --execute` runs notebooks in dependency order, only after `preflight` succeeds; it expects full GPU, source and Drive access. For individual debugging:

```bash
# plan-only stage (no training)
python run.py --config configs/amazon_v2.example.json run-stage --stage e1-train --model lightgcn_plus --seed 2023
# actual Colab GPU execution
python run.py --config configs/amazon_v2.example.json run-stage --stage e1-train --model lightgcn_plus --seed 2023 --execute
# after finishing E1/E2/E3A/E3B, example E3C
python run.py --config configs/amazon_v2.example.json run-stage --stage e3c-train --execute
# E4 fixed recovery design — 3 seeds at layer 1 for each model invocation
python run.py --config configs/amazon_v2.example.json run-stage --stage e4-train --model LightGCN --layer 1 --execute
```

The wrapped notebooks are copied into `<run_root>/<run_id>/runtime/notebooks/` with the OLD `Data_SNA_Group14` path replaced by the new run root. **The original notebooks, checkpoints, profiles and Drive results are never overwritten by this wrapper.** If original notebook logic has other hardcoded paths, execution may stop, and its failure log is saved to the branch. Do not circumvent safety checks by reading old results into the Gemini run.

**Note on Colab:** `nbclient` executes notebooks using an IPython kernel and is unverified against the current online Colab GPU environment. If Colab's Drive mount or RLMRec CUDA behavior is incompatible, inspect the staged notebook and run it interactively, keeping the same branch paths and hashes.
