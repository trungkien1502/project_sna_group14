# Kiểm thử trước khi bàn giao

- Đã kiểm tra schema với `nbformat.validate` và Python AST của cả 2 notebook.
- Synthetic unit test: paper prompt payload fallback, parser JSON trong markdown fences, mocked ada-002 vector dim 1536, shards resume, đóng gói 7 `.pkl`, output SHA256 các ma trận, bootstrap notebook nhóm.
- Kiểm tra source GitHub pinned commit của **15/15** notebook chọn: tất cả chứa Drive root group để thay, không đưa legacy vào danh sách chạy chính.
- Chưa kiểm thử Gemini qua DFLO và OpenAI API bằng key thực tế trong phiên này; chưa chạy đầy đủ 9.332+11.000 profiles hoặc E1–E4.
- Không sửa / xóa bất kỳ dữ liệu hoặc notebook trên Google Drive của người dùng trong lượt tạo artifact này.
