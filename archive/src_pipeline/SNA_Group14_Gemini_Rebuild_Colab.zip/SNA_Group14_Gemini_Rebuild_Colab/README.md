# SNA Group 14 — Gemini semantic data → E1–E4 (Google Colab)

**Phạm vi:** Xây lại **phần tạo dữ liệu semantic**, sau đó **sử dụng lại notebook E1–E4 của nhóm trên GitHub**, không tái lập thuật toán RLMRec từ đầu. Bộ dữ liệu gốc RLMRec và báo cáo thực nghiệm cũ không bị thay đổi.

## Các file Colab

1. `00_BUILD_GEMINI_DATA_Colab.ipynb` (notebook chính):
   - Audit ma trận `trn_mat.pkl` / `val_mat.pkl` / `tst_mat.pkl`, mapper tác giả.
   - Index Amazon Books 2014 metadata và reviews gốc; reviews chỉ được tham gia prompts nếu `(uid,iid)` có trong train; ghi nhận giới hạn kiểm chứng event-level.
   - Tạo **2 file JSONL prompts**, không tạo 20.332 prompt files rời.
   - Gemini qua **DFLO** (`ag/gemini-3.8-flash`) tạo item profiles trước, user profiles sau; checkpoint JSONL và token usage từng request.
   - OpenAI API chính thức **`text-embedding-ada-002`**, chỉ mã hóa `summarization`; checkpoint từng shard.
   - Xuất đủ 7 `.pkl`, giữ nguyên SHA256 của 3 ma trận; tạo `dataset_manifest.json`.
2. `01_PREPARE_GROUP_EXPERIMENTS_Colab.ipynb` (chạy sau notebook chính):
   - Clone GitHub nhóm 14 đúng commit đã audit.
   - Chọn **15 notebook chính** E1, E2, E3A–E3D, E4 và QA.
   - Tạo **bản sao đã đổi đường dẫn** của các notebook này trong Google Drive, tự mount Drive mỗi Colab Runtime, giữ nguyên code logic bên trong.
   - Mọi output đều nằm trong `Data_SNA_Group14/experiments_gemini/gemini_dflo_ada002_v1/experiments/`, **không ghi đè** `Data_SNA_Group14/experiments/` cũ.

### Chuẩn bị tối thiểu

- Google Colab có quyền truy cập `/content/drive/MyDrive/Data_SNA_Group14`.
- Dữ liệu gốc nhóm: `data/raw/amazon/{trn_mat,val_mat,tst_mat,usr_prf,itm_prf,usr_emb_np,itm_emb_np}.pkl` (notebook KHÔNG đọc 4 file profile/embedding tác giả ở bước Gemini).
- Amazon Books metadata: `data/external/amazon_books/meta_Books.json.gz` (đã có từ bước trước của dự án).
- Amazon Books **raw reviews 2014**: `data/external/amazon_books/reviews_Books_5.json.gz` hoặc đường dẫn tương đương chỉnh trong notebook. File này có thể cần tải riêng, dung lượng rất lớn; 5-core là tập con và không bảo đảm đủ mọi cặp train. Notebook có cell tải *bị khóa mặc định* để tránh tải nhầm.
- DFLO API key có quyền `ag/gemini-3.8-flash`; OpenAI API key có quyền `text-embedding-ada-002`.
- Lưu key trong **Colab Secrets** (`DFLO_API_KEY`, `OPENAI_API_KEY`) hoặc nhập qua `getpass` khi chạy. Tuyệt đối không lưu key trong code/Drive/GitHub.

## Thứ tự thao tác

1. Upload `00_BUILD_GEMINI_DATA_Colab.ipynb` lên Colab, bật CPU là đủ cho phần chuẩn bị, chạy **từng cell theo thứ tự**, không `Run all`.
2. Giữ `ALLOW_DFLO_CALLS=False` để kiểm tra prompts/metadata/reviews. Sau đó đổi `True` và chạy **3 item profiles pilot**; kiểm tra token/JSON rồi mới tăng `NEW_REQUEST_LIMIT` theo quota của dflo. User prompts chỉ được tạo khi hoàn tất 9.332 item profiles, rồi làm user pilot → đủ 11.000 profiles.
3. Giữ `ALLOW_OPENAI_CALLS=False` để kiểm tra điều kiện; bật `True` sau khi có đủ profiles, tạo embedding theo shards, từng bước. Cần gọi `embed_kind('item', ...)` và `embed_kind('user', ...)` cho tới khi đủ shards. Không cần embed lại khi training E1–E4.
4. Đổi `DO_PACKAGE=True`, chạy cell xuất 7 `.pkl`; phải thấy `DATASET PACKAGE PASS`.
5. Upload/mở `01_PREPARE_GROUP_EXPERIMENTS_Colab.ipynb`, chạy tuần tự. Các notebook E1–E4 được tạo trong thư mục Drive `.../group_notebooks_prepared/`. Mở từng notebook từ đó trên Colab; trước khi training cần chọn GPU.
6. Chạy E1 training + TopK → E2 → E3A/B → E3C (weight 0.01 **chỉ tái sử dụng E1 Gemini mới**) → E3D → E4. Mọi kết quả mới cô lập trong thư mục `experiments_gemini/<RUN_ID>/experiments/` để đối chiếu báo cáo cũ.

## Các notebook nhóm được chọn

- E1: `03_E1_Full_Training`, `04_E1_Export_TopK`, `05_E1_Most_Popular`, `06_E1_Summary`.
- E2: `07_E2_Popularity_Bias`.
- E3A: `08_E3A_Semantic_Alignment_Ablation_FIXED`.
- QA: `09_Audit`.
- E3B: `10_E3B_Popularity_Bias_Analysis`.
- E3C: `11_E3C_Semantic_Weight_Sensitivity_FIXED_v3`, `E3C_Export_TopK_Fixed`, `12_E3C_Analysis_Weight_Sensitivity`.
- E3D: `E3D_Semantic_Collaborative_Agreement_Drive`.
- E4: `E4_RQ3_Training_FIXED_Drive_Checkpoints`, `E4_RQ3_Export_TopK_FIXED`, `E4_RQ3_Analysis`.

**Không chọn** bản `11_E3C_Semantic_Weight_Sensitivity` cũ, `E3C_Colab` workflow không liên quan sensitivity, các E4 cũ, hoặc E3D ZIP thay thế Drive.

## Provenance và hạn chế khoa học cần ghi trong báo cáo

- Đây là bản *reconstruction* của prompt builder Amazon, không phải chính mã batch Amazon hoàn chỉnh do RLMRec công bố. System instructions Amazon **giữ đúng từ nguồn tác giả**.
- User prompts mặc định gồm **toàn bộ train history**, không được đưa validation/test vào. Có thể đặt `MAX_USER_HISTORY` để hạn chế chi phí nhưng đó là một thay đổi protocol và phải tạo `RUN_ID` mới.
- Item không có description dùng metadata còn lại và tối đa 3 reviews *được ánh xạ về cặp train*, hoặc để `None` nếu không có bằng chứng; trường hợp không đủ thông tin bị đánh dấu và phải xử lý minh bạch.
- Ma trận train/validation/test nhị phân **không cho phép xác nhận chính xác review event nào thuộc train**; review matching theo cặp `(user,item)` chỉ là rào chắn ở mức cặp, không bảo đảm không rò rỉ event-level.
- Alias gateway `ag/gemini-3.8-flash` có thể trả về model khác tên `gemini-3.8-flash-n` trong phản hồi; code ghi lại cả hai tên.
- Giá dflo do gateway quyết định, không được giả định bằng bảng giá Google trực tiếp. API OpenAI embedding được tính dựa trên `total_tokens`, nhưng phải kiểm tra pricing hiện hành và quyền API của tài khoản.
- Không huấn luyện E1–E4 trong lúc tạo file notebook; kết quả training chỉ xuất hiện **sau khi nhóm tự thực thi trên Colab/GPU**.

## Trạng thái kiểm thử trước khi gửi

- Notebook schema và cú pháp Python (ngoại trừ các lệnh `%pip` hợp lệ của IPython): **PASS**.
- Mocked `OpenAI.embeddings.create` → lưu shards → ghép user/item embeddings → xuất 7 `.pkl`: **PASS với synthetic mini dataset**.
- Bootstrap và chuyển đường dẫn của một notebook giả lập: **PASS**.
- Đối chiếu **15/15 notebook** thực tế trên GitHub: đều có đường dẫn gốc phù hợp để chuyển sang workspace riêng (kiểm tra tĩnh).
- **Chưa** gọi DFLO/OpenAI thật trên bộ dữ liệu đầy đủ, **chưa** đọc reviews thực tế trên Drive để audit mức coverage, **chưa** chạy huấn luyện GPU E1–E4. Không gọi đây là end-to-end PASS.

**Không xóa pipeline cũ ngay từ notebook.** Sau khi bộ mới được kiểm chứng, mới chuyển các thư mục pipeline thử nghiệm cũ vào Thùng rác nếu nhóm muốn.
